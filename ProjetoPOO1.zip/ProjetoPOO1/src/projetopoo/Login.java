/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetopoo;

/**
 * A classe Login é onde validará login e senha 
 * @author Pedro
 */
public class Login {

    private String usuario = "admin";
    private String senha = "admin";

    public boolean checkCredentials(String User, String Pass) {

        if (User.equals(usuario) && senha.equals(Pass)) {
            return true;
        } else {
            return false;
        }
    }

    public String getUsuario() {
        return usuario;
    }

    public String getSenha() {
        return senha;
    }

}
