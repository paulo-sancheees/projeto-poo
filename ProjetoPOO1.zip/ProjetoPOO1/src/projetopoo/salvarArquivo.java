/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetopoo;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

/**
 * A classe salvarArquivo é responsável por criar um arquivo .txt de nome referente ao componente cadastrado
 * @author Pedro
 */
public class salvarArquivo {


    public void salvar(Produto novoProduto) throws FileNotFoundException, IOException {

        OutputStream os = new FileOutputStream(novoProduto.getNome() + ".txt");
        OutputStreamWriter osw = new OutputStreamWriter(os);
        BufferedWriter bw = new BufferedWriter(osw);

        bw.write("Nome: " + novoProduto.getNome());
        bw.newLine();
        bw.write("Quantidade: " + novoProduto.getQuantidade());
        bw.newLine();
        bw.write("Descrição: " + novoProduto.getDescricao());
        bw.close();
    }

    
}
