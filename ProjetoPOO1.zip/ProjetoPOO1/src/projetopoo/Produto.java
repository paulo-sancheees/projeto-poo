/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetopoo;

/**
 *
 * @author Pedro
 * A classe produto é referente aos componentes que serão cadastrados no almoxarifado com seus respectivos atributos: nome, descrição e quantidade
 */
public class Produto {
    
   private String nome;
   private String descricao;
   private int quantidade;
   
   /**
     * @return nome do componente
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome do componente
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return descricao do componente
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     * @param descricao do componente
     */
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    /**
     * @return quantidade de componentes no estoque
     */
    public int getQuantidade() {
        return quantidade;
    }

    /**
     * @param quantidade de componentes
     */
    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
    
    public int retirarProduto(int quantidade){
        
        return quantidade;
        
    }

    Object getCodigo() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
   
  
}
